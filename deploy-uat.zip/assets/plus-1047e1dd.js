import{c as e}from"./index-0231291c.js";/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const o=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]],c=e("plus",o);export{c as P};
//# sourceMappingURL=plus-1047e1dd.js.map
